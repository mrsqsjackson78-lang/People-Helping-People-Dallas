
#include "crow.h"

int main() {
    crow::SimpleApp app;

    CROW_ROUTE(app, "/health")([]{
        return "OK";
    });

    app.port(18080).run();
}
