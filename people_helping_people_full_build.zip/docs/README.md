
# People Helping People – Full Build

Includes REST API, JWT auth, messaging, Qt/Web/Mobile frontends, and CI.

This is a safe, scalable foundation for a community help platform.
