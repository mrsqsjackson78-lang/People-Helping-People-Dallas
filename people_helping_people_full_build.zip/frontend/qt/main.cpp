
#include <QApplication>
#include <QPushButton>

int main(int argc, char *argv[]) {
  QApplication app(argc, argv);
  QPushButton btn("Create Help Request");
  btn.show();
  return app.exec();
}
