
People Helping People – Production Build
Includes full CRUD, JWT auth, encrypted messaging, notifications, admin dashboard,
Docker deployment, and mobile packaging base.
