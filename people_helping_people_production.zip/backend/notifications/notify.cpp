
void notify(int user){ }
